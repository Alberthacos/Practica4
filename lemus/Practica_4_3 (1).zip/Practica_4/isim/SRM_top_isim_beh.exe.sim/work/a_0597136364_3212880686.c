/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/gbara/OneDrive/Documentos/Circuitos/Practica_4/shift_add3.vhd";
extern char *IEEE_P_3620187407;

unsigned char ieee_p_3620187407_sub_2546454082_3965413181(char *, char *, char *, int );
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );


static void work_a_0597136364_3212880686_p_0(char *t0)
{
    char t16[16];
    char t19[16];
    char t21[16];
    char *t1;
    char *t2;
    int t3;
    int t4;
    char *t5;
    char *t6;
    int t7;
    int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t17;
    unsigned char t18;
    char *t20;
    char *t22;
    char *t23;
    unsigned int t24;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 6716);
    *((int *)t1) = 0;
    t2 = (t0 + 6720);
    *((int *)t2) = 19;
    t3 = 0;
    t4 = 19;

LAB2:    if (t3 <= t4)
        goto LAB3;

LAB5:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t9 = (7 - 7);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t5 = (t0 + 1968U);
    t6 = *((char **)t5);
    t13 = (19 - 7);
    t14 = (t13 * 1U);
    t15 = (0 + t14);
    t5 = (t6 + t15);
    memcpy(t5, t1, 8U);
    xsi_set_current_line(55, ng0);
    t1 = (t0 + 6724);
    *((int *)t1) = 0;
    t2 = (t0 + 6728);
    *((int *)t2) = 7;
    t3 = 0;
    t4 = 7;

LAB7:    if (t3 <= t4)
        goto LAB8;

LAB10:    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t9 = (19 - 19);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t5 = (t0 + 4144);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    t17 = (t12 + 56U);
    t20 = *((char **)t17);
    memcpy(t20, t1, 12U);
    xsi_driver_first_trans_fast(t5);
    t1 = (t0 + 4016);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(49, ng0);
    t5 = (t0 + 1968U);
    t6 = *((char **)t5);
    t5 = (t0 + 6716);
    t7 = *((int *)t5);
    t8 = (t7 - 19);
    t9 = (t8 * -1);
    xsi_vhdl_check_range_of_index(19, 0, -1, *((int *)t5));
    t10 = (1U * t9);
    t11 = (0 + t10);
    t12 = (t6 + t11);
    *((unsigned char *)t12) = (unsigned char)2;

LAB4:    t1 = (t0 + 6716);
    t3 = *((int *)t1);
    t2 = (t0 + 6720);
    t4 = *((int *)t2);
    if (t3 == t4)
        goto LAB5;

LAB6:    t7 = (t3 + 1);
    t3 = t7;
    t5 = (t0 + 6716);
    *((int *)t5) = t3;
    goto LAB2;

LAB8:    xsi_set_current_line(57, ng0);
    t5 = (t0 + 1968U);
    t6 = *((char **)t5);
    t9 = (19 - 11);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t5 = (t6 + t11);
    t12 = (t16 + 0U);
    t17 = (t12 + 0U);
    *((int *)t17) = 11;
    t17 = (t12 + 4U);
    *((int *)t17) = 8;
    t17 = (t12 + 8U);
    *((int *)t17) = -1;
    t7 = (8 - 11);
    t13 = (t7 * -1);
    t13 = (t13 + 1);
    t17 = (t12 + 12U);
    *((unsigned int *)t17) = t13;
    t18 = ieee_p_3620187407_sub_2546454082_3965413181(IEEE_P_3620187407, t5, t16, 4);
    if (t18 != 0)
        goto LAB11;

LAB13:
LAB12:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t9 = (19 - 15);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t5 = (t16 + 0U);
    t6 = (t5 + 0U);
    *((int *)t6) = 15;
    t6 = (t5 + 4U);
    *((int *)t6) = 12;
    t6 = (t5 + 8U);
    *((int *)t6) = -1;
    t7 = (12 - 15);
    t13 = (t7 * -1);
    t13 = (t13 + 1);
    t6 = (t5 + 12U);
    *((unsigned int *)t6) = t13;
    t18 = ieee_p_3620187407_sub_2546454082_3965413181(IEEE_P_3620187407, t1, t16, 4);
    if (t18 != 0)
        goto LAB14;

LAB16:
LAB15:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t9 = (19 - 19);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t5 = (t16 + 0U);
    t6 = (t5 + 0U);
    *((int *)t6) = 19;
    t6 = (t5 + 4U);
    *((int *)t6) = 16;
    t6 = (t5 + 8U);
    *((int *)t6) = -1;
    t7 = (16 - 19);
    t13 = (t7 * -1);
    t13 = (t13 + 1);
    t6 = (t5 + 12U);
    *((unsigned int *)t6) = t13;
    t18 = ieee_p_3620187407_sub_2546454082_3965413181(IEEE_P_3620187407, t1, t16, 4);
    if (t18 != 0)
        goto LAB17;

LAB19:
LAB18:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t9 = (19 - 18);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t5 = xsi_get_transient_memory(19U);
    memcpy(t5, t1, 19U);
    t6 = (t0 + 1968U);
    t12 = *((char **)t6);
    t13 = (19 - 19);
    t14 = (t13 * 1U);
    t15 = (0 + t14);
    t6 = (t12 + t15);
    memcpy(t6, t5, 19U);

LAB9:    t1 = (t0 + 6724);
    t3 = *((int *)t1);
    t2 = (t0 + 6728);
    t4 = *((int *)t2);
    if (t3 == t4)
        goto LAB10;

LAB20:    t7 = (t3 + 1);
    t3 = t7;
    t5 = (t0 + 6724);
    *((int *)t5) = t3;
    goto LAB7;

LAB11:    xsi_set_current_line(58, ng0);
    t17 = (t0 + 1968U);
    t20 = *((char **)t17);
    t13 = (19 - 11);
    t14 = (t13 * 1U);
    t15 = (0 + t14);
    t17 = (t20 + t15);
    t22 = (t21 + 0U);
    t23 = (t22 + 0U);
    *((int *)t23) = 11;
    t23 = (t22 + 4U);
    *((int *)t23) = 8;
    t23 = (t22 + 8U);
    *((int *)t23) = -1;
    t8 = (8 - 11);
    t24 = (t8 * -1);
    t24 = (t24 + 1);
    t23 = (t22 + 12U);
    *((unsigned int *)t23) = t24;
    t23 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t19, t17, t21, 3);
    t25 = (t0 + 1968U);
    t26 = *((char **)t25);
    t24 = (19 - 11);
    t27 = (t24 * 1U);
    t28 = (0 + t27);
    t25 = (t26 + t28);
    t29 = (t19 + 12U);
    t30 = *((unsigned int *)t29);
    t31 = (1U * t30);
    memcpy(t25, t23, t31);
    goto LAB12;

LAB14:    xsi_set_current_line(61, ng0);
    t6 = (t0 + 1968U);
    t12 = *((char **)t6);
    t13 = (19 - 15);
    t14 = (t13 * 1U);
    t15 = (0 + t14);
    t6 = (t12 + t15);
    t17 = (t21 + 0U);
    t20 = (t17 + 0U);
    *((int *)t20) = 15;
    t20 = (t17 + 4U);
    *((int *)t20) = 12;
    t20 = (t17 + 8U);
    *((int *)t20) = -1;
    t8 = (12 - 15);
    t24 = (t8 * -1);
    t24 = (t24 + 1);
    t20 = (t17 + 12U);
    *((unsigned int *)t20) = t24;
    t20 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t19, t6, t21, 3);
    t22 = (t0 + 1968U);
    t23 = *((char **)t22);
    t24 = (19 - 15);
    t27 = (t24 * 1U);
    t28 = (0 + t27);
    t22 = (t23 + t28);
    t25 = (t19 + 12U);
    t30 = *((unsigned int *)t25);
    t31 = (1U * t30);
    memcpy(t22, t20, t31);
    goto LAB15;

LAB17:    xsi_set_current_line(64, ng0);
    t6 = (t0 + 1968U);
    t12 = *((char **)t6);
    t13 = (19 - 19);
    t14 = (t13 * 1U);
    t15 = (0 + t14);
    t6 = (t12 + t15);
    t17 = (t21 + 0U);
    t20 = (t17 + 0U);
    *((int *)t20) = 19;
    t20 = (t17 + 4U);
    *((int *)t20) = 16;
    t20 = (t17 + 8U);
    *((int *)t20) = -1;
    t8 = (16 - 19);
    t24 = (t8 * -1);
    t24 = (t24 + 1);
    t20 = (t17 + 12U);
    *((unsigned int *)t20) = t24;
    t20 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t19, t6, t21, 3);
    t22 = (t0 + 1968U);
    t23 = *((char **)t22);
    t24 = (19 - 19);
    t27 = (t24 * 1U);
    t28 = (0 + t27);
    t22 = (t23 + t28);
    t25 = (t19 + 12U);
    t30 = *((unsigned int *)t25);
    t31 = (1U * t30);
    memcpy(t22, t20, t31);
    goto LAB18;

}

static void work_a_0597136364_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(76, ng0);

LAB3:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = (11 - 3);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 4208);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast_port(t6);

LAB2:    t11 = (t0 + 4032);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0597136364_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(78, ng0);

LAB3:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = (11 - 7);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 4272);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast_port(t6);

LAB2:    t11 = (t0 + 4048);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0597136364_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(80, ng0);

LAB3:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = (11 - 11);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 4336);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast_port(t6);

LAB2:    t11 = (t0 + 4064);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0597136364_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0597136364_3212880686_p_0,(void *)work_a_0597136364_3212880686_p_1,(void *)work_a_0597136364_3212880686_p_2,(void *)work_a_0597136364_3212880686_p_3};
	xsi_register_didat("work_a_0597136364_3212880686", "isim/SRM_top_isim_beh.exe.sim/work/a_0597136364_3212880686.didat");
	xsi_register_executes(pe);
}
